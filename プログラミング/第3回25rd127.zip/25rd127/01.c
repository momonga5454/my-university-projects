#include<stdio.h>
int main(void) 
{
    int d1,d2;
    scanf("%d",&d1);
    scanf("%d",&d2);
    printf("%d\n",d1+d2);
    printf("%d\n",d1-d2);
    printf("%d\n",d1*d2);
    printf("%d %d\n",d1/d2,d1%d2);
    return 0;
}