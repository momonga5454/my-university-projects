#include<stdio.h>
int main(void)
{
    
    char ren;
    scanf("%c",&ren);
    if(ren=='*'){
        printf("asterisk\n");
    }
    else if(ren=='|'){
        printf("vertical line\n");
    }
    else if(ren=='~'){
        printf("tilde\n");
    }



    return 0;

}