#include<stdio.h>
int main(void)
{

    printf("%ld\n",sizeof(char));
    printf("%ld\n",sizeof(int));
    printf("%ld\n",sizeof(float));
    printf("%ld\n",sizeof(double));
    return 0;
}