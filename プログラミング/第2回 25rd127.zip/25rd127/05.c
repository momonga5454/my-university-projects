#include<stdio.h>
int main(void) 
{
    double x=2.25;
    
    printf("%.1f\n",x);
    printf("%.6f\n",x);
    printf("%.20f\n",x);

    return 0;
}