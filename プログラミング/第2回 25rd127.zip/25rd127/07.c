#include<stdio.h>
int main(void) 
{
    int x,y;
    scanf("%d",&x);
    scanf("%d",&y);
    printf("%d\n",x*x+2*x*y+y);

    return 0;
}
