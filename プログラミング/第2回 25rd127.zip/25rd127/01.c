#include<stdio.h>
int main(void) 
{
    char c;
    scanf("%c",&c);
    printf("%c\n",c);

    return 0;
}