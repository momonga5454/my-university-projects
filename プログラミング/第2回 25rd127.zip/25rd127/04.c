#include<stdio.h>
int main(void) 
{
    double c;
    scanf("%lf",&c);
    printf("%f\n",c * -1);

    return 0;
}