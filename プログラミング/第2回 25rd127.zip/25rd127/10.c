#include<stdio.h>
int main(void) 
{
    int x;
    scanf("%d",&x);
    x=x+5;

    printf("%d\n",x/10*10);
    return 0;

}