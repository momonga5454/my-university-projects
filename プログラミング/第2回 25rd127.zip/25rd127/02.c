#include<stdio.h>
int main(void) 
{
    char c;
    scanf("%c",&c);
    printf("%c ",c);
    printf("%c ",c);
    printf("%c ",c);
    return 0;
}