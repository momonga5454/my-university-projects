#include<stdio.h>
int main(void) 
{
    int c;
    scanf("%d",&c);
    printf("%d\n",c);

    return 0;
}