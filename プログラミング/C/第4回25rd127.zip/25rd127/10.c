#include<stdio.h>
int main(void)
{
    double i;
    
    
    for(i=-1.5;i!=25.5;i+=3){
        printf("%f\n",i);
    }
    

    return 0;
}