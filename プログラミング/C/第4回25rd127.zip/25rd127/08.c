#include <stdio.h>

int main() {
    char ch,c;
    do{
        scanf("%c",&ch);
        printf("%d\n",ch);
        
    }
    while (ch!='E');
        scanf("%c",&ch);
        printf("%d\n",ch);
    
    return 0;
}