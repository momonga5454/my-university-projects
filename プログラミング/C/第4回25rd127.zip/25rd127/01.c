#include<stdio.h>
int main(void)
{
    int i;
    
    for(i=1;i<=3;i++){
        printf("Tokyo Denki University\n");
        printf("Information System Design\n");
    }

    return 0;
}