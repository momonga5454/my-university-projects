#include<stdio.h>

int main(void)
{
    double x=1.234;
    printf("%f\n",x*5);
    return 0;
}