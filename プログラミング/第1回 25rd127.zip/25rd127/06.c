#include<stdio.h>

int main(void)
{
    int a=2;
    printf("%d\n",a*10);
    return 0;
}
