#include<stdio.h>

int main(void)
{
    char c='a';
    printf("%c\n",c);

    return 0;
}