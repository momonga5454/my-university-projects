#include<stdio.h>
int main(void)
{
    printf("%d\n",23+8);
    return 0;
}