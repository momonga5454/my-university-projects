#include<stdio.h>
int main(void)
{
    printf("%f\n",1.25*0.2);
    return 0;
}