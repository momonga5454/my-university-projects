#include <stdio.h>


int main(void)
{   
    printf("Tokyo Denki University\n25RD127 Tsukui Ryou\n");

    return 0;
}