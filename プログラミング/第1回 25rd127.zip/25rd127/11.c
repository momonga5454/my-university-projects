#include<stdio.h>
int main(void)
{
    int a=12;
    int b=0;
    printf("%d\n",a/b);

    return 0;
}