#include<stdio.h>
int main(void)
{
    char c='a';
    printf("%c\n",c);
    printf("%c\n",c+1);
    printf("%c\n",c+2);

    return 0;
}
