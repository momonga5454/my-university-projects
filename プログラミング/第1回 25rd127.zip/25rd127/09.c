#include<stdio.h>
int main(void)
{
    char c='a';
    printf("%d\n",c);

    return 0;
}